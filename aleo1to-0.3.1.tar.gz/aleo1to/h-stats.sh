#!/usr/bin/env bash
set -ex

stats_raw=`curl -v -s http://127.0.0.1:32159`

if [[ $? -ne 0 || -z $stats_raw ]]; then
  echo -e "${YELLOW}Failed to read $miner stat from 127.0.0.1:32159${NOCOLOR}"
  exit
fi

bus_numbers=`echo $stats_raw | jq -r '[.threads[].bus]'`
hs_units="hs"
uptime=`echo $stats_raw | jq -r '.uptime'`
hs=`echo $stats_raw | jq -r '[.threads[].hr]'`

total_hs=`echo $hs | jq -r '. | add' | bc -l`
total_khs=`echo "scale=3; $total_hs/1000" | bc -l`
acc=`echo $stats_raw | jq -r '.air[0]'`
version=`echo $stats_raw | jq -r '.version'`
temp=`nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader | jq --raw-input --slurp 'split("\n") | map(select(. != ""))'`
fan=`nvidia-smi --query-gpu=fan.speed --format=csv,noheader | sed -e "s/ %//" | jq --raw-input --slurp 'split("\n") | map(select(. != ""))'`

algo='aleo'
stats=$(jq -nc --arg uptime "${uptime//s/}" \
                 --arg algo "$algo" \
                 --arg hs_units "$hs_units" \
                 --arg total_khs "$total_khs" \
                 --arg ver "$version" \
                 --argjson temp "$temp" \
                 --argjson fan "$fan" \
                 --argjson bus_numbers "$bus_numbers" \
                 --argjson hs "$hs" \
                 --arg acc $acc \
                 '{total_khs: $total_khs|tonumber, $hs, $hs_units,
                   uptime: $uptime|tonumber, $algo, ar:[$acc|tonumber, 0, 0, 0],
                   $temp, $fan, $bus_numbers, $ver}')

# debug
# echo uptime=$uptime
# echo algo=$algo
# echo hs_units=$hs_units
# echo total_khs=$khs
# echo ver=`miner_ver`
# echo bus_numbers=$bus_numbers
# echo hs=$hs_dec
# echo $stats