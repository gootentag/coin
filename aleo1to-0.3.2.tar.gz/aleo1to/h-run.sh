#!/usr/bin/env bash
cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

#[[ `ps aux | grep "1to-miner" | grep -v grep | wc -l` != 0 ]] &&
#  echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" && exit 1
#cd $MINER_DIR/$MINER_VER

. ${CUSTOM_CONFIG_FILENAME}_env

./1to-miner `cat $CUSTOM_CONFIG_FILENAME` 2>&1 | tee --append $CUSTOM_LOG_BASENAME.log