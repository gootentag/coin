#!/usr/bin/env bash

conf=""
[[ ! -z $CUSTOM_URL ]] &&
	$CUSTOM_URL="ws://pool.aleo1.to:32000"

if [[ ! -z $CUSTOM_USER_CONFIG ]]
then
	GPU_SELECT=`echo "$CUSTOM_USER_CONFIG" | sed 's/.*\-\-gpu\-select[= ]\([0-9,]*\).*/\1/'`
	CUSTOM_USER_CONFIG=`echo "$CUSTOM_USER_CONFIG" | sed 's/[^ ]*\-\-gpu\-select[= ]\([0-9,]*\)//'`
fi

ADDRESS="${CUSTOM_TEMPLATE%.*}"
conf+=" --ws $CUSTOM_URL --address $ADDRESS"
conf+=" $CUSTOM_USER_CONFIG"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

env=""
[[ ! -z $GPU_SELECT ]] &&
	env+="export CUDA_VISIBLE_DEVICES=${GPU_SELECT}"$'\n'
echo "$env" > "${CUSTOM_CONFIG_FILENAME}_env"
chmod +x "${CUSTOM_CONFIG_FILENAME}_env"